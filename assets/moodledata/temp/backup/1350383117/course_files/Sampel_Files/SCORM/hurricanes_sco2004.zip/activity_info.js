/**
 *  ==================================================
 *  SoftChalk LessonBuilder
 *  Activity activity_info.js
 *  Copyright 2007 SoftChalk LLC
 *  All Rights Reserved.
 *
 *  http://www.softchalk.com
 *  ==================================================
 */

q_done_a=new Array();
scoreQa=new Array();
score_a=new Array();
show_restart_a=new Array();
num_pages=8;
actOrder=new Array(1);
actOrder[0]=6;

//a_num=6;
a_value6=0;
scoreQa[6]=false;
q_done_a[6]=false;
score_a[6]=0;
show_restart_a[6]=true;

