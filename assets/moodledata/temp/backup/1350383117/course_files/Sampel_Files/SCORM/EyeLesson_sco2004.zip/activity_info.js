/**
 *  ==================================================
 *  SoftChalk LessonBuilder
 *  Activity activity_info.js
 *  Copyright 2007 SoftChalk LLC
 *  All Rights Reserved.
 *
 *  http://www.softchalk.com
 *  ==================================================
 */

q_done_a=new Array();
scoreQa=new Array();
score_a=new Array();
show_restart_a=new Array();
num_pages=5;
actOrder=new Array(3);
actOrder[0]=10;
actOrder[1]=2;
actOrder[2]=3;

//a_num=10;
a_value10=0;
scoreQa[10]=false;
q_done_a[10]=false;
score_a[10]=0;
show_restart_a[10]=true;

//a_num=2;
a_value2=0;
scoreQa[2]=false;
q_done_a[2]=false;
score_a[2]=0;
show_restart_a[2]=true;

//a_num=3;
a_value3=0;
scoreQa[3]=false;
q_done_a[3]=false;
score_a[3]=0;
show_restart_a[3]=true;

